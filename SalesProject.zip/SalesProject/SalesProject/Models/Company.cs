﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesProject.Models
{
    public class Company
    {
      public int CompanyID { get; set; }
      public string CompanyName { get; set; }
      public string CompanyAddress { get; set; }
    
      public string CompanyCity { get; set; }  
      public string CompanyState { get; set; }  
      public int CompanyZipcode { get; set; }
        
        //navigation
    public ICollection<Contact> Contacts { get; set; }
    }
}
