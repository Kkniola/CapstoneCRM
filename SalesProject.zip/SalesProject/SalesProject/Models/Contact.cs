﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesProject.Models
{
    public class Contact
    {
        public int ContactID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Suffix  { get; set; }
        public string Prefix { get; set; }
        public string Title { get; set; }
        public int RoleID { get; set; }
        public DateTime DOB { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int ZipCode { get; set; }
        public string Country { get; set; }
        public int Cellphone { get; set; }
        public int Workphone { get; set; }
        public string ContactMethod { get; set; }
        public int CompanyID { get; set; }
        public int CompanyLocationID { get; set; }
        public string SourceID { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime LastDateContacted { get; set; }
        public string Comment { get; set; }

        //navigation property

        public Company Company { get; set; }
        public Role Role { get; set; }
        public Source Source { get; set; }

    }
}
