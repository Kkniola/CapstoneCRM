﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesProject.Models
{
    public class Source
    {
        public int SourceID { get; set; }
        public string SourceDescription { get; set; }

        //navigation //ICollection deals with larger areas that relate to multiple tables
        public ICollection<Contact> Contacts { get; set; }
    }
}
