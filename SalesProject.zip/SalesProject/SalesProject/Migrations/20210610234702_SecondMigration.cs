﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SalesProject.Migrations
{
    public partial class SecondMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Address",
                table: "Company");

            migrationBuilder.DropColumn(
                name: "State",
                table: "Company");

            migrationBuilder.DropColumn(
                name: "Zipcode",
                table: "Company");

            migrationBuilder.AddColumn<string>(
                name: "CompanyAddress",
                table: "Company",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CompanyCity",
                table: "Company",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CompanyState",
                table: "Company",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CompanyZipcode",
                table: "Company",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    RoleID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Company = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.RoleID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Contact_RoleID",
                table: "Contact",
                column: "RoleID");

            migrationBuilder.AddForeignKey(
                name: "FK_Contact_Role_RoleID",
                table: "Contact",
                column: "RoleID",
                principalTable: "Role",
                principalColumn: "RoleID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contact_Role_RoleID",
                table: "Contact");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropIndex(
                name: "IX_Contact_RoleID",
                table: "Contact");

            migrationBuilder.DropColumn(
                name: "CompanyAddress",
                table: "Company");

            migrationBuilder.DropColumn(
                name: "CompanyCity",
                table: "Company");

            migrationBuilder.DropColumn(
                name: "CompanyState",
                table: "Company");

            migrationBuilder.DropColumn(
                name: "CompanyZipcode",
                table: "Company");

            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "Company",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "State",
                table: "Company",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Zipcode",
                table: "Company",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
