﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SalesProject.Data;
using SalesProject.Models;

namespace SalesProject.Pages.Contacts
{
    public class EditModel : PageModel
    {
        private readonly SalesProject.Data.SalesProjectContext _context;

        public EditModel(SalesProject.Data.SalesProjectContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Contact Contact { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Contact = await _context.Contact
                .Include(c => c.Company)
                .Include(c => c.Source).FirstOrDefaultAsync(m => m.ContactID == id);
            if (Contact == null)
            {
                return NotFound();
            }
            ViewData["CompanyID"] = new SelectList(_context.Set<Company>(), "CompanyID", "CompanyID");
            ViewData["SourceID"] = new SelectList(_context.Set<Source>(), "SourceID", "SourceID");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Contact).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContactExists(Contact.ContactID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool ContactExists(int id)
        {
            return _context.Contact.Any(e => e.ContactID == id);
        }
    }
}
