﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SalesProject.Data;
using SalesProject.Models;

namespace SalesProject.Pages.Sources
{
    public class DetailsModel : PageModel
    {
        private readonly SalesProject.Data.SalesProjectContext _context;

        public DetailsModel(SalesProject.Data.SalesProjectContext context)
        {
            _context = context;
        }

        public Source Source { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Source = await _context.Source.FirstOrDefaultAsync(m => m.SourceID == id);

            if (Source == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
